# Menu
plugin Menu pour dotclear 2 de [Adjaya](http://aiguebrun.adjaya.info/post/20090202/Telegarger-le-Plugin-Menu-pour-Dotclear2-Download)

Menu vous permet d’afficher un menu pouvant avoir plusieurs niveaux sur votre blog, si votre thème le supporte.
