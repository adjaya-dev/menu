<?php
# Template style menu
$template_theme_style = array(
	'LI_A_ACTIVE'	=> 'id="active"'
);

# Widget style menu
//$widget_theme_style = array(
//);