<?php
# Template style menu
$template_theme_style = array(
	'UL'	=> 'class="nav navbar-nav navbar-menu-drop"',
	'LI'	=> 'class="dropdown"',
	'LI_A' => 'class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"',
	'UL_SM' => 'class="dropdown-menu"'
);