<?php
# Template style menu
$template_theme_style = array(
	'UL'					=> 'id="global-nav"',
	'LI_A_FIRST'			=> 'onclick="setActiveStyleSheet(\'default\'); return true;"',
	'LI_A_ACTIVE_FIRST'		=> 'onclick="setActiveStyleSheet(\'default\'); return true;"',
	'LI_LAST'				=> 'id="rss"',
	'LI_ACTIVE_LAST'		=> 'id="rss"',
	'UL_SM'					=> 'class="sub-nav"'
);

# Widget style menu
//$widget_theme_style = array(
//);