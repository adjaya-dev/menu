<?php
# Template style menu
$template_theme_style = array(
	'LI_ACTIVE'			=> 'class="active"',
	'LI_ACTIVE_SM'		=> 'class="active"',
	'LI_PARENT'		=> 'class="active-ancestor"',
	'LI_A'					=> 'class="fadeThis"',
	'LI_A_FIRST'			=> 'class="fadeThis home"',
	'LI_A_ACTIVE_FIRST'			=> 'class="fadeThis home"',
	'A_CUSTOMIZED'			=> '<span class="title">%s</span><span class="pointer"></span>',
	'LI_SMPARENT'			=> 'class="active-parent"',
);