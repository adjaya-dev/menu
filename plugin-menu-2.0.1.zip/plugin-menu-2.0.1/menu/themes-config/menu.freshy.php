<?php
# Template style menu
$template_theme_style = array(
	'UL'					=> 'class="menu"',
	'LI'					=> 'class="page_item"',
	'LI_ACTIVE'				=> 'class="current_page_item"',
	//'LI_FIRST'				=> '',
	//'LI_ACTIVE_FIRST'			=> '',
	'LI_LAST'				=> 'class="page_item last_menu"',
	'LI_ACTIVE_LAST'		=> 'class="current_page_item last_menu"',
	//'LI_A'					=> '',
	//'LI_A_ACTIVE'			=> '',
	'LI_A_FIRST'			=> 'class="first_menu"',
	'LI_A_ACTIVE_FIRST'		=> 'class="first_menu"',
	'LI_A_LAST'				=> 'class="last_menu"',
	'LI_A_ACTIVE_LAST'		=> 'class="last_menu"'
);

# Widget style menu
//$widget_theme_style = array(
//);