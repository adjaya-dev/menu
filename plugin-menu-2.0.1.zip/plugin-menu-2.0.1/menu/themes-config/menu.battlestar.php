<?php
# Template style menu
$template_theme_style = array(
	'UL'				=> 'id="global-nav"',
	'LI_LAST'			=> 'id="rss"',
	'LI_ACTIVE_LAST'	=> 'id="rss"'
);

# Widget style menu
//$widget_theme_style = array(
//);