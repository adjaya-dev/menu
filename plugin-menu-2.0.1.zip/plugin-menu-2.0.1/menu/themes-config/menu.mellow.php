<?php
# Template style menu
$template_theme_style = array(
	'UL'	=> 'id="global-nav"'
);

# Widget style menu
//$widget_theme_style = array(
//);